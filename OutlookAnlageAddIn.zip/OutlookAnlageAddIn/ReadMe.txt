/// Outlook Add In by Konrad Werner - Contact: konradw01@outlook.de ///

Installation:
	
	- Open the setup.exe
	- It will come up some Message from Windows, because there is no official License. -> "Unbekannter Verleger"
	- Just press Install/Installieren
	- After that it should come up some Message like "Your Installation was successful"

Deactivate:
	
	- Go to "Datei"/"File" in the top, left corner
	- Go to "Optionen"/"Options" in the buttom, left corner
	- Go to "Add-Ins" and click on the buttom site "Los"/"Go"
	- Disable OutlookAnlageAddIn and press OK

Deinstallation:

	- Press Windows on your buttom, left corner of your Desktop
	- Type "Apps" and open "Apps and Features"
	- Search "OutlookAnlageAddIn" and delete it

Instructions:

	If you click Send on a new E-Mail, the Add In will search your written Mail if it Contains Keywords like Attachment/Anlage and Keywords like that.
	If it finds a Keyword, it will ask you, if you want to Attach a File, if u didnt attached one. Afterwards you can attach a file.
	After attaching a file, you can attach more files if u need to. To Send the Mail, just press Send again.

/// Thank your for using my Software! - Feel free to contact me for bugs or new Features! - Go with Email or join my Discord: https://discord.gg/KFG8uJHAcr! ///